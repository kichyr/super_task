#include <string>
#include <algorithm>


// toBinaryRepresentation returns binary representation
// of given numver as a string
std::string toBinaryRepresentation(unsigned x);